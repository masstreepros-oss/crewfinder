# CrewFinder Platform Audit Report
**Date:** March 15, 2026  
**Target:** Arbor Expo March 26 — 11 days out  
**Goal:** Production-ready for 200 new user onboarding

---

## Executive Summary

CrewFinder has **real users and real data** — 22 workers with skills, 13 with photos, 3 reviews, 1 job posted, and 6,582 pre-loaded companies. However, **both the admin page and main app are broken** due to a Content Security Policy (CSP) that silently blocks external JavaScript libraries from loading. This is the #1 blocker.

---

## Critical Issues (Must Fix Before Expo)

### 🔴 ISSUE 1: Content Security Policy Blocks Scripts
**Impact:** Admin page won't login. App may fail on some devices.  
**Root Cause:** The `_headers` and `netlify.toml` files set a CSP that restricts which CDNs can serve JavaScript. Even though we added `cdn.jsdelivr.net`, the browser's service worker is caching the OLD CSP and serving stale headers.  
**Fix:** Remove the CSP entirely from both `_headers` and `netlify.toml`. Also bump the service worker cache version from `v3` to `v4` to bust the cache.

### 🔴 ISSUE 2: Service Worker Caching Old Pages
**Impact:** Users see stale/broken versions even after we deploy fixes.  
**Root Cause:** `sw.js` caches all HTML pages aggressively (cache version `v3`). Old broken versions persist in users' browsers.  
**Fix:** Bump `CACHE_VERSION` to `v4` in sw.js. This forces all browsers to re-download fresh pages.

### 🔴 ISSUE 3: Admin Page — `const db` Before Initialization
**Impact:** "Cannot access db before initialization" error on login.  
**Root Cause:** `const db = supabase.createClient(...)` crashes if the Supabase library hasn't loaded yet (blocked by CSP). Using `const` means JavaScript won't let you reference `db` at all after the crash.  
**Fix:** Change to `var db` with try-catch. Already done in latest admin.html but CSP is still blocking the library.

### 🔴 ISSUE 4: Profiles RLS — Admin Can Only See 1 User
**Impact:** Admin dashboard shows empty user list. Mike reports "all users missing."  
**Root Cause:** There are 22+ real users (based on worker_skills table having 22 unique worker_ids), but the profiles RLS policy only returns 1 row for the authenticated admin. The "profiles_select_all" policy may have been dropped or overridden.  
**Fix:** Run SQL to re-enable the SELECT policy on profiles: `CREATE POLICY "profiles_read_all" ON profiles FOR SELECT USING (true);`

---

## Data Inventory (SAFE — Do Not Touch)

| Table | Rows | Notes |
|-------|------|-------|
| profiles | 22+ (1 visible via RLS) | Real users — RLS hiding them from admin |
| unclaimed_businesses | 6,582 | Pre-loaded companies with claim codes |
| worker_skills | 204 | 22 unique workers |
| work_photos | 35 | 13 unique workers |
| reviews | 3 | All 5-star, real reviews |
| jobs | 1 | 1 real job posting |
| call_log | 0 | Caller portal data |
| messages | 0 | No messages yet |
| waitlist | 0 | Empty |

---

## Page-by-Page Status

| Page | URL | Status | Issues |
|------|-----|--------|--------|
| Landing | / | ✅ Works | Clean, no JS dependencies |
| Main App | /app | ⚠️ Partially works | Uses unpkg (allowed by CSP), but service worker may cache old version |
| Admin | /admin | 🔴 Broken | Supabase CDN blocked by CSP, login fails |
| Caller | /caller | 🔴 Broken | Twilio SDK issues, can be dropped per Mike |
| Demo | /demo | ✅ Works | Static demo page |
| Waitlist | /waitlist | ⚠️ Untested | Should work if Supabase loads |

---

## Files That Need Updating

### 1. `_headers` — Remove CSP
Remove the Content-Security-Policy line entirely. Keep other security headers.

### 2. `netlify.toml` — Remove CSP  
Same — remove the CSP line from the headers section.

### 3. `sw.js` — Bust Cache
Change `const CACHE_VERSION = 'v3'` to `const CACHE_VERSION = 'v4'`

### 4. `admin.html` — Fix Login + Encoding
- Use `var db` instead of `const db` with try-catch
- Use same CDN as app.html (unpkg.com) for consistency
- Fix all garbled UTF-8 characters (emojis)
- Both ADMIN_EMAILS entries include michaelrabasco@gmail.com

### 5. Supabase SQL — Fix Profiles RLS
Run in SQL editor to let admin see all users:
```sql
-- Check existing policies
SELECT * FROM pg_policies WHERE tablename = 'profiles';

-- If profiles_select_all is missing, recreate it:
CREATE POLICY "profiles_select_all" ON profiles FOR SELECT USING (true);
```

---

## Expo Readiness Checklist

- [ ] Admin page login works
- [ ] Admin dashboard shows all users
- [ ] Main app (/app) loads and functions on mobile
- [ ] New user signup flow works (worker + business)
- [ ] Business claim flow works with claim codes
- [ ] Profile editing works
- [ ] Job posting works
- [ ] Service worker cache busted (v4)
- [ ] All pages load clean (no garbled characters)
- [ ] Landing page (/index.html) has clear CTA for expo attendees

---

## Recommended Action Plan

**Step 1 (Now):** Upload fixed `_headers`, `netlify.toml`, `sw.js`, and `admin.html` to GitHub  
**Step 2 (Now):** Run the profiles RLS fix SQL in Supabase dashboard  
**Step 3 (After deploy):** Test admin login, verify all 22+ users visible  
**Step 4 (After deploy):** Test /app signup flow on mobile  
**Step 5 (This week):** Full mobile testing of all user flows  
**Step 6 (Before expo):** Prepare landing page with expo-specific CTA
